<div class="sidebar">
  <ul>
    <li><a title="" href="./dashboard.php"><i class="material-icons">home</i> Dashboard</a></li>
    <li><a title="" href="./reservations.php"><i class="material-icons">event_available</i> Reservations</a></li>
    <li><a title="" href="./edit-hotel.php"><i class="material-icons">hotel</i> Edit Hotel Info</a></li>
    <li><a title="" href="./logout.php"><i class="material-icons">directions_run</i> Logout</a></li>
  </ul>
</div>
