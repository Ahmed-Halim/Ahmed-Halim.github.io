<div id="logo">Hotel Manager Panel</div>

<header><?php echo getPageTitle(); ?></header>
