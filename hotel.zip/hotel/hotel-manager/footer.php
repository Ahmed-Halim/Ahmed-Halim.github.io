<!-- JavaScript -->
<script src="includes/jquery/jquery.min.js"></script>
<script src="includes/scripts.js"></script>
