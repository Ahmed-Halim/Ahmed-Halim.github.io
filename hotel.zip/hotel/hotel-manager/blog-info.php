  <title><?php echo getPageTitle(); ?> </title>
  <!-- Meta Tags -->
  <meta charset="UTF-8">
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <!-- Favicon Tag -->
  <link rel="icon" type="image/x-icon" href="images/favicon.png" />
  <!-- Mobile Meta Tag -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- CSS -->
  <link href="includes/bootstrap.min.css" rel="stylesheet">
  <link href="includes/style.css" rel="stylesheet">
  <link href="includes/material-icons/material-icons.css" rel="stylesheet">
