<div id="logo">Admin Panel</div>

<header><?php echo getPageTitle(); ?></header>
